function [J, grad] = costFunction(theta, X, y)
%COSTFUNCTION Compute cost and gradient for logistic regression
%   J = COSTFUNCTION(theta, X, y) computes the cost of using theta as the
%   parameter for logistic regression and the gradient of the cost
%   w.r.t. to the parameters.

% Initialize some useful values
m = length(y); % number of training examples


J = 0;
grad = zeros(size(theta));





h = sigmoid(X*theta);
u = ones(size(y)) - y;
j = ones(size(h)) - h;


T = (-y.*log(h))- (u.*log(j));

J = (T' * (ones(size(T))))/m;


grad = (1/m)*(h - y)'*X; 	





% =============================================================

end
