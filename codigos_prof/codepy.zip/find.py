# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

#Função em python que busca na matriz um elemento e devolve a posição
# dele na matriz. Caso haja mais de um, retornará o ultimo.
# Não deve ser alterado

def find(M, x):
    posx = -20
    posy = -20
    for i in range (M.shape[0]):
        for j in range(M.shape[1]):
            if M[i,j] == x:
                posx = i
                posy = j
    return posx,posy
                
