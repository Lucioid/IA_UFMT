# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

# Função em python que mostra o caminho percorrida em solução do quebra-cabeça
# A função recebe um nó de busca __node__ e mostra o caminho percorrido.
#

from show import show
def reconstruct_path(node):
	if not (node.Prev is None):
		if node.Prev is None:
			show(node.State)
		else:
			reconstruct_path(node.Prev)
			show(node.State)
			print("")
