# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

# Classe em python que implementa a descrição dos nós de busca
# Cada nó contem uma referência para o nó que o descobriu (i.e., nó 
# visitado no passo anterior), o estado atual (i.e., configuração da matriz) e
# o número de movimentos feitos até o momento.
# Parar criar um novo nó de busca n faça:
# n = Node(State,cost,None)
#
# em que State e cost correspondem, respecticamente oa estado e ao custo
# do nó. O custo do nó é igual ao número de passos efetivamente percorridos
# pelo algoritmo até sua descoberta (i.e., o custo de um nó não raíz é
# 1 + o custo do nó que o descobriu)


def cmp(a, b):
    return (a > b) - (a < b)

class Node:

    def __init__(self, State,f, Prev):
        self.State = State
        self.f = f
        self.Prev = Prev
        #self.priority = priority

    def __hash__(self):
        return id(self)

    def get_priority(self):
        return self.priority

    def set_priority(self, priority):
        self.priority = priority 

    def get_f(self):
        return self.f
    def get_State(self):
        return self.State
    def get_Prev(self):
        return self.Prev
    def set_f(self, nf):
        self.f = nf
    def set_State(self,nState):
        self.State = nState
    def set_Prev(self, nPrev):
        self.Prev = nPrev

    def __cmp__(self, another):
        return cmp(self.priority, another.priority)
