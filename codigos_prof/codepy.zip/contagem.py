# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

# Função em python que deve contar a quantidade elementos
# com valor igual a 1 em uma matriz M de entrada

import numpy as np

def contagem(M):
	count = 0
	return count
