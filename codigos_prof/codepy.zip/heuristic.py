# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

# Função em python que deve implementar uma nova heurística.
# A função deve receber uma matriz __S__ com o estado do quebra-cabeça
# e devolver uma estimativa __dist__ da quantida de movimentos necessários
# para chegar ao objetivo.

import numpy as np

def heuristic(S):
	dist = 0

	return dist
