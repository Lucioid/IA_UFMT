# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

# Função em python que implementa a heurística de hamming.
# Este arquivo não deve ser alterado.

import numpy as np
from find import find

def hamming(M):
	count = 0
	obj = np.array([[1, 2, 3], [4, 5, 6], [7, 8 , 9]])
	diff = obj - M
	count = np.count_nonzero(diff) 
	x,y = find(M,9)
	if (x != 2 and y != 2): 
			count = count - 1
	return count
