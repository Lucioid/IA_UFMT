# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

import numpy as np
from astar import astar
from manhattan import manhattan
from hamming import hamming
from reconstruct_path import reconstruct_path

M = np.array([[4, 1, 3],[9, 2, 5], [7, 8, 6]])

# Crie mais casos de testes abaixo
