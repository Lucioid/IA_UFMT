# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

# Função em python que deve implementar a heurística de manhattan.
# A função deve receber uma matriz __State__ representando o estado 
# qualquer do jogo e deve calcular a soma das distâncias ( horizontal e
# vertical) de cada célula desse estado para a posição que ela deveria
# ocupar no estado objetivo.
#

import numpy as np
from find import find

def manhattan(State):
	dist = 0
	return dist
		
