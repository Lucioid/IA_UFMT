# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

# Função em python que deve implementar o algoritmo A-estrela
# A função deve receber uma matriz __M__ com estado inicial do quebra-cabeça
# o apontador para a função heuristica __h__ e devolver um no de busca __n__
# com o estado objetivo. Para que seja possível resconstruir o caminho percorrido
# até a solução, cada nó produzido pelo algoritmo de busca deve conter uma
# referência para o nó que o descobriu (i.e. no visitado no passo anterior)
# Para executar o algoritmo para um estado S com a heuristica de gamming por
# S = np.array([[4, 1, 3],[9, 2, 5], [7, 8, 6]])
# node = astar(S,hamming)
#
# Extra: A variável __error__ deve ser utilizada para identificar jogos
# que não possuem solução 


from Node import Node
import numpy as np
from show import show
from hamming import hamming
from manhattan import manhattan
from PriorityQueue import PriorityQueue
from legal_moves import legal_moves
from do_move import do_move
from reconstruct_path import reconstruct_path
import copy

def astar(M,h):
	error = 0
	# Estado objetivo
	O = np.array([[1, 2, 3], [4, 5, 6], [7, 8 , 9]])

	# Cria uma fila de prioridades vazia
	queue = PriorityQueue()
	
	# Cria um nono no com a matriz M (estado inicial) e um custo
	node = Node(M,0,None)

	# Insere o no na fila de prioridades, onde o custo do nó é 
	#(node.f + h(node.State), onde h é um apontador para a função 
	#heuristica considerada
	queue.insert(node, (node.f + h(node.State)))

	# laço prinicipal do algoritmo A-estrela - È interrompido quando a fila fica vazia
	while(not queue.isempty()):

		# remove um no __m__ com a menor prioridade da fila queue
		m = queue.extractMin()
		n = m
	return n,error
		
