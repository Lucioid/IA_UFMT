# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

# Função em python que mostra o estado do jogo na tela.

def show(M):
    print("\n")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            if (M[i,j] == 9):
                print('  '),
            else:
                print(" " + str(M[i,j])),
        print('')
