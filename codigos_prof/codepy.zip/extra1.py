# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

# Script em python que deve ser utilizado para testar a implementação
# das tarefas extras do exercício.
# Este arquivo não deve ser alterado

import numpy as np
from astar import astar
from manhattan import manhattan
from hamming import hamming
from reconstruct_path import reconstruct_path

# Teste 1
M = np.array([[4, 1, 3],[9, 2, 5], [7, 8, 6]])
m,error = astar(M,manhattan)
# descomente esta linha para ver as movimentações
#reconstruct_path(m)
assert (error == 1)
print("Teste 1: OK")

# Teste 2
M = np.array([[9, 1, 3],[4, 2, 5], [7, 8, 6]])
m,error = astar(M,manhattan)
assert (error == 1)
print("Teste 2: OK")

# Teste 3
M = np.array([[4, 9, 5],[3, 8, 6], [7, 1, 2]])
m,error = astar(M,manhattan)
assert (error == 1)
print("Teste 3: OK")


# Teste 4
M = np.array([[5, 3, 2],[7, 6, 4], [8, 1, 9]])
m,error = astar(M,heuristic)
assert (np.array_equal(m.State,[[1, 2, 3],[4, 5, 6],[7, 8, 9]])) == True
print("Teste 4: OK")

# Teste 5
M = np.array([[4, 6, 7],[9, 5, 8], [2, 3, 1]])
m,error = astar(M,heuristic)
assert (np.array_equal(m.State,[[1, 2, 3],[4, 5, 6],[7, 8, 9]])) == True
print("Teste 5: OK")

print("Sua implementação está correta!")
