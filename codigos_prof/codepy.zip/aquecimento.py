# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

# Script em python utilizado para testar a implementação do exercicio de aquecimento
import numpy as np
from contagem import contagem

assert (contagem(np.ones((10,10), dtype = int)) == 100)
print("Teste 1: OK")

assert (contagem(np.array([[1, 0, 1], [1, 0, 1],[1, 0, 1]])) == 6)
print("Teste 2: OK")

assert (contagem(np.eye(3, dtype=int)) == 3)
print("Teste 3: OK")

assert (contagem(np.array([[1, 1, 1], [1, 0, 1],[1, 0, 1]])) == 7)
print("Teste 4: OK")

assert (contagem(np.array([[0, 1, 0], [0, 0, 1],[0, 0, 1]])) == 3)
print("Teste 5: OK")

print('Sua implementação está correta!')
