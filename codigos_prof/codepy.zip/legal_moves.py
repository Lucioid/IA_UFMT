# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

"""
 Função em python que implementa a descrição das ações validas
 em um estado do quebra cabeça de oito-peças
 Ela recebe como parametro uma matriz M, e retorna um vetor moves
 com todas as peças que podem ser movimentadas nesse estado.
"""

from find import find
def legal_moves(M):
    moves = []
    [l,c] = find(M,9)
    if l - 1 >= 0:
        moves.append(M[l-1,c])
    if l + 1 <= 2:
        moves.append(M[l+1,c])
    if c - 1 >=0:
        moves.append(M[l,c-1])
    if c + 1 <= 2:
        moves.append(M[l,c+1])
    return moves
    
    
    
    

