# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2
 
"""
 Função em  python que implementa o modelo de transição do quebra cabeça de oito-peças
 Ela recebe como uma matriz M, e uma peça a ser movimentada (p_value) e
 devolve uma nova matriz nM com o estado do jogo apos a movimentação
"""
def do_move(M, p_value):
    blank_value = 9
    nM = M.ravel() # achatamento da matriz em um vetor
    p = -1
    blank_p = -1
    for i in range(len(nM)):
        if (nM[i] == blank_value):
            blank_p = i
        if (nM[i] == p_value):
            p = i
    nM[blank_p] = p_value
    nM[p] = blank_value
    nM = nM.reshape(3,3)
    return nM
