# -*- coding: utf-8 -*-

 #Universidade Federal de Mato Grosso
 #Faculdade de Engenharia 
 #Inteligencia Artificial - 2019/2

# Classe em python que implementa a fila de prioridades

# Para declarar uma fila de prioridades vazia faça:
# q = PriorityQueue()

# Para inserir um no com prioridade p em uma fila q ja criada, faça:
# q.insert(no,p)

# Para remover um no com a menor prioiridade, utilize a função
# extractMin assim:

# m = q.extractMin()


from Node import Node
import numpy as np
from priorityq import PQ


class PriorityQueue:
    def __init__(self):
        self.pq = PQ()

    def insert(self, node, priority):
        node.set_priority(priority)
        self.pq.push(node)

    def extractMin(self):
        return self.pq.pop()

    def isempty(self):
        return len(self.pq) == 0
