function [ opp ] = opposite_player( player )
    
    if player == 1,
        opp = 2;
    else
        opp = 1;
    end

end

